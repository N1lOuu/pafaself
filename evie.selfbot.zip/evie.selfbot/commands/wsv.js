exports.run = (client, msg, args) => {
  /* args is an array of strings which corresponds to the message split by space, with the command removed. */
  /* example: `/test blah foo thing` , where `["blah", "foo", "thing"]` is the value of `args`. */
  // YOUR CODE HERE
    //if (!args[1]) return this.send(msg, 'Need to specify a name, an ID or mention the user.')
    //if(!args[2]) return this.send(msg, 'Tu doit pr√©ciser la **raison**')
    //if(!args[3]) return this.send(msg, 'Tu doit pr√©ciser la **gravit√©**')
      msg.edit(':mega: **WARN** : ' + args[0] + ' Pub sur le serveur  **__FAIBLE__**' );

 
   }


exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'wsv',
  description: 'Commande pour warn un memvre qui a commis une infraction des r√®gles du Discord ! ',
  usage: 'wsv [arg0] '
};