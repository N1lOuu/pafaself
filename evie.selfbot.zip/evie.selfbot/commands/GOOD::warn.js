exports.run = (client, msg, args) => {
  /* args is an array of strings which corresponds to the message split by space, with the command removed. */
  /* example: `/test blah foo thing` , where `["blah", "foo", "thing"]` is the value of `args`. */
  // YOUR CODE HERE
    //if (!args[1]) return this.send(msg, 'Need to specify a name, an ID or mention the user.')
    //if(!args[2]) return this.send(msg, 'Tu doit préciser la **raison**')
    //if(!args[3]) return this.send(msg, 'Tu doit préciser la **gravité**')
      msg.channel.sendMessage(':mega: **WARN** : ' + args[0] + ' ' + args[1] + ' ' + args[2]);
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'warn',
  description: 'Commande pour warn un memvre qui a commis une infraction des règles du Discord ! ',
  usage: 'warn [arg0] [arg1] [args2]'
};