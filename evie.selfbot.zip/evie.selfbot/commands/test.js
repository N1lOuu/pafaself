exports.run = async (client, msg, args) => {
  // Insert Test Here
};


exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'test',
  description: 'Dumping grounds for any test I make.',
  usage: 'test'
};
