module.exports = (client, error) => {
  console.log(`Error has been issued: ${error}`);
};