module.exports = (client, warn) => {
  console.log(`Warning has been issued: ${warn}`);
};